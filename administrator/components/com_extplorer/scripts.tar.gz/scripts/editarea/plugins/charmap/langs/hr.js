editArea.add_lang("hr",{
charmap_but: "Virtualna tipkovnica",
charmap_title: "Virtualna tipkovnica",
charmap_choose_block: "Odaberi blok s jezikom",
charmap_insert:"Ubaci taj znak"
});
