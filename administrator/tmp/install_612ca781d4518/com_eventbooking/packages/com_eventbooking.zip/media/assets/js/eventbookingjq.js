if (typeof(Eb) === 'undefined') {
    var Eb = {};
}
Eb.jQuery = jQuery.noConflict();

